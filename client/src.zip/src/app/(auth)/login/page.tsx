"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Home, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

interface LoginPageProps {
  // Define standard Next.js page props if needed for params/searchParams
  searchParams?: { [key: string]: string | string[] | undefined };
}

export default function LoginPage({ searchParams }: LoginPageProps) {
  const [showPassword, setShowPassword] = useState<boolean>(false);

  const togglePasswordVisibility = (): void => {
    setShowPassword((prev) => !prev);
  };

  return (
    <main className="min-h-screen w-full flex flex-col lg:flex-row font-sans">
      
      {/* Left Column - Dark Auth Form */}
      <section className="w-full lg:w-[50%] xl:w-[55%] bg-c-bg-750 min-h-screen flex flex-col text-white pb-10 lg:pb-0">
        
        {/* Header / Nav */}
        <header className="flex justify-between items-center p-6 lg:p-8 w-full">
          <Link href="https://repeatsms.com" className="flex items-center gap-1 cursor-pointer">
            <Image src="/rsms-logo.webp" alt="RepeatSMS Logo" width={192} height={67} />
          </Link>
          <Link 
            href="https://repeatsms.com" 
            className="flex flex-col items-center justify-center text-xs text-c-gray-400 hover:text-white transition-colors"
          >
            <Home className="w-5 h-5 mb-1 text-c-orange-500" />
            Home
          </Link>
        </header>

        {/* Form Container */}
        <div className="flex-1 flex flex-col justify-center items-center px-6 w-full max-w-[520px] mx-auto mt-10 lg:mt-0">
          
          <div className="text-center mb-10 w-full">
            <h1 className="text-2xl lg:text-3xl font-medium mb-3">Welcome Back!</h1>
            <p className="text-c-gray-400 text-sm">Access your account with your secure login</p>
          </div>

          <div className="w-full mb-6">
            <h2 className="text-xl font-medium mb-1">Sign in</h2>
            <p className="text-sm text-c-gray-400">
              Don&apos;t have account?{" "}
              <Link href="/register" className="text-c-orange-500 hover:text-c-orange-400 transition-colors">
                Create Now
              </Link>
            </p>
          </div>

          <form 
            onSubmit={(e: React.FormEvent<HTMLFormElement>) => e.preventDefault()} 
            className="w-full space-y-5"
          >
            {/* Email/Username */}
            <div className="space-y-2">
              <Label htmlFor="identifier" className="text-c-gray-300 font-normal">Email/Username</Label>
              <Input 
                id="identifier" 
                placeholder="Email/Username" 
                className="bg-transparent border-c-gray-600 focus-visible:ring-c-green-400 text-white h-11" 
              />
            </div>

            {/* Password */}
            <div className="space-y-2">
              <Label htmlFor="password" className="text-c-gray-300 font-normal">Password</Label>
              <div className="relative">
                <Input 
                  id="password" 
                  type={showPassword ? "text" : "password"} 
                  placeholder="******" 
                  className="bg-transparent border-c-gray-600 focus-visible:ring-c-green-400 text-white pr-10 h-11" 
                />
                <button 
                  type="button" 
                  onClick={togglePasswordVisibility} 
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-c-gray-400 hover:text-white transition-colors"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Pin Code */}
            <div className="space-y-2">
              <Label htmlFor="pin" className="text-c-gray-300 font-normal">Pin Code</Label>
              <Input 
                id="pin" 
                placeholder="Secret Code (Created by yourself)" 
                className="bg-transparent border-c-gray-600 focus-visible:ring-c-green-400 text-white h-11" 
              />
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="remember" 
                  className="border-c-gray-500 rounded bg-transparent data-[state=checked]:bg-transparent data-[state=checked]:border-white" 
                />
                <Label htmlFor="remember" className="text-sm font-normal text-c-gray-300 cursor-pointer">
                  Remember me
                </Label>
              </div>
              <Link href="/forgot-password" className="text-sm text-c-orange-500 hover:text-c-orange-400 transition-colors">
                Forgot Password?
              </Link>
            </div>

            {/* Submit Button */}
            <Button 
              type="submit" 
              className="w-full bg-c-green-400 hover:bg-c-green-500 text-white font-semibold text-base h-12 mt-4 transition-colors"
            >
              Sign in
            </Button>
          </form>
        </div>
      </section>

      {/* Right Column - Light Promotional Area */}
      <section 
        className="hidden w-full lg:w-[50%] xl:w-[45%] bg-white lg:flex flex-col justify-between p-6 relative bg-cover bg-center min-h-[50vh] lg:min-h-screen"
        style={{ backgroundImage: "url('/auth-bg.png')" }}
      >
        <div className="w-full max-w-3xl mx-auto z-10 pt-4 lg:pt-8 text-center lg:text-left">
          <h1 className="text-48-semibold-inter text-c-bg-750 mb-2">Sign Up Today</h1>
          <p className="text-24-semibold-inter text-c-bg-750 ">experience the difference.</p>
        </div>

        <div className="flex-1 w-full flex items-center justify-center relative z-10 my-8 lg:my-12">
          <div className="relative w-full max-w-4xl aspect-[16/10]">
            <Image
              src="/auth-3.png"
              alt="RepeatSMS Dashboard Interface"
              fill
              className="object-contain"
              priority
            />
          </div>
        </div>

        <footer className="w-full z-10 text-center text-sm text-c-gray-500 pb-4">
          &copy; 2014-2026 RepeatSMS. All Rights Reserved.
        </footer>
      </section>
      
    </main>
  );
}