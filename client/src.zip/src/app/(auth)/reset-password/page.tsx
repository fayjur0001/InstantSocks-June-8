"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Home, Eye, EyeOff, ShieldCheck, ArrowLeft, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface ResetPasswordPageProps {
  searchParams?: { [key: string]: string | string[] | undefined };
}

export default function ResetPasswordPage({
  searchParams,
}: ResetPasswordPageProps) {
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [showConfirmPassword, setShowConfirmPassword] =
    useState<boolean>(false);
  const [password, setPassword] = useState<string>("");
  const [confirmPassword, setConfirmPassword] = useState<string>("");
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [error, setError] = useState<string>("");

  const togglePasswordVisibility = (): void => setShowPassword((p) => !p);
  const toggleConfirmPasswordVisibility = (): void =>
    setShowConfirmPassword((p) => !p);

  // Simple strength check
  const getStrength = (pwd: string): { label: string; color: string; width: string } => {
    if (pwd.length === 0) return { label: "", color: "bg-c-gray-700", width: "w-0" };
    if (pwd.length < 6) return { label: "Too short", color: "bg-c-red-500", width: "w-1/4" };
    if (pwd.length < 8) return { label: "Weak", color: "bg-c-orange-500", width: "w-2/4" };
    if (!/[A-Z]/.test(pwd) || !/[0-9]/.test(pwd))
      return { label: "Fair", color: "bg-c-yellow-400", width: "w-3/4" };
    return { label: "Strong", color: "bg-c-green-400", width: "w-full" };
  };

  const strength = getStrength(password);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    setError("");

    if (password.length < 8) {
      setError("Password must be at least 8 characters long.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match. Please try again.");
      return;
    }

    setSubmitted(true);
  };

  return (
    <main className="min-h-screen w-full flex flex-col lg:flex-row font-sans">
      {/* Left Column - Dark Auth Form */}
      <section className="w-full lg:w-[50%] xl:w-[55%] bg-c-bg-750 min-h-screen flex flex-col text-white pb-10 lg:pb-0">
        {/* Header / Nav */}
        <header className="flex justify-between items-center p-6 lg:p-8 w-full">
          <Link
            href="https://repeatsms.com"
            className="flex items-center gap-1 cursor-pointer"
          >
            <Image
              src="/rsms-logo.webp"
              alt="RepeatSMS Logo"
              width={192}
              height={67}
            />
          </Link>
          <Link
            href="https://repeatsms.com"
            className="flex flex-col items-center justify-center text-xs text-c-gray-400 hover:text-white transition-colors"
          >
            <Home className="w-5 h-5 mb-1 text-c-orange-500" />
            Home
          </Link>
        </header>

        {/* Form Container */}
        <div className="flex-1 flex flex-col justify-center items-center px-6 w-full max-w-[520px] mx-auto mt-10 lg:mt-0">
          {!submitted ? (
            <>
              {/* Icon */}
              <div className="mb-8 flex items-center justify-center w-16 h-16 rounded-full bg-c-green-400/10 border border-c-green-400/30">
                <ShieldCheck className="w-7 h-7 text-c-green-400" />
              </div>

              <div className="text-center mb-10 w-full">
                <h1 className="text-2xl lg:text-3xl font-medium mb-3">
                  Create a new password
                </h1>
                <p className="text-c-gray-400 text-sm leading-relaxed">
                  Your new password must be different from your previous
                  passwords. Choose something strong and memorable — you&apos;ll
                  need it every time you sign in.
                </p>
              </div>

              <div className="w-full mb-6">
                <h2 className="text-xl font-medium mb-1">Reset Password</h2>
                <p className="text-sm text-c-gray-400">
                  All set after this.{" "}
                  <Link
                    href="/login"
                    className="text-c-orange-500 hover:text-c-orange-400 transition-colors"
                  >
                    Back to Login
                  </Link>
                </p>
              </div>

              <form onSubmit={handleSubmit} className="w-full space-y-5">
                {/* New Password */}
                <div className="space-y-2">
                  <Label
                    htmlFor="password"
                    className="text-c-gray-300 font-normal"
                  >
                    New Password
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your new password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="bg-transparent border-c-gray-600 focus-visible:ring-c-green-400 text-white pr-10 h-11"
                    />
                    <button
                      type="button"
                      onClick={togglePasswordVisibility}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-c-gray-400 hover:text-white transition-colors"
                      aria-label={
                        showPassword ? "Hide password" : "Show password"
                      }
                    >
                      {showPassword ? (
                        <EyeOff size={18} />
                      ) : (
                        <Eye size={18} />
                      )}
                    </button>
                  </div>

                  {/* Password strength bar */}
                  {password.length > 0 && (
                    <div className="space-y-1">
                      <div className="h-1 w-full bg-c-gray-700 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${strength.color} ${strength.width}`}
                        />
                      </div>
                      <p className="text-xs text-c-gray-500">
                        Strength:{" "}
                        <span
                          className={
                            strength.label === "Strong"
                              ? "text-c-green-400"
                              : strength.label === "Fair"
                              ? "text-c-yellow-400"
                              : "text-c-orange-400"
                          }
                        >
                          {strength.label}
                        </span>
                        {strength.label !== "Strong" && (
                          <span className="ml-1 text-c-gray-600">
                            — use 8+ chars, uppercase & numbers
                          </span>
                        )}
                      </p>
                    </div>
                  )}
                </div>

                {/* Confirm New Password */}
                <div className="space-y-2">
                  <Label
                    htmlFor="confirmPassword"
                    className="text-c-gray-300 font-normal"
                  >
                    Confirm New Password
                  </Label>
                  <div className="relative">
                    <Input
                      id="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      placeholder="Re-enter your new password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                      className="bg-transparent border-c-gray-600 focus-visible:ring-c-green-400 text-white pr-10 h-11"
                    />
                    <button
                      type="button"
                      onClick={toggleConfirmPasswordVisibility}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-c-gray-400 hover:text-white transition-colors"
                      aria-label={
                        showConfirmPassword
                          ? "Hide confirm password"
                          : "Show confirm password"
                      }
                    >
                      {showConfirmPassword ? (
                        <EyeOff size={18} />
                      ) : (
                        <Eye size={18} />
                      )}
                    </button>
                  </div>

                  {/* Match indicator */}
                  {confirmPassword.length > 0 && (
                    <p
                      className={`text-xs ${
                        password === confirmPassword
                          ? "text-c-green-400"
                          : "text-c-red-400"
                      }`}
                    >
                      {password === confirmPassword
                        ? "✓ Passwords match"
                        : "✗ Passwords do not match"}
                    </p>
                  )}
                </div>

                {/* Inline error */}
                {error && (
                  <p className="text-sm text-c-red-400 bg-c-red-400/10 border border-c-red-400/20 rounded-md px-3 py-2">
                    {error}
                  </p>
                )}

                {/* Submit */}
                <div className="pt-2 space-y-3">
                  <Button
                    type="submit"
                    className="w-full bg-c-green-400 hover:bg-c-green-500 text-white font-semibold text-base h-11 transition-colors"
                  >
                    Set New Password
                  </Button>

                  <div className="flex items-center justify-center">
                    <Link
                      href="/login"
                      className="flex items-center gap-2 text-sm text-c-gray-400 hover:text-white transition-colors"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      Back to Login
                    </Link>
                  </div>
                </div>
              </form>
            </>
          ) : (
            /* Success State */
            <div className="text-center w-full">
              <div className="mb-8 flex items-center justify-center w-16 h-16 rounded-full bg-c-green-400/10 border border-c-green-400/30 mx-auto">
                <CheckCircle2 className="w-7 h-7 text-c-green-400" />
              </div>
              <h1 className="text-2xl lg:text-3xl font-medium mb-3">
                Password updated!
              </h1>
              <p className="text-c-gray-400 text-sm leading-relaxed mb-6">
                Your password has been reset successfully. You can now sign in
                to your RepeatSMS account with your new password.
              </p>
              <p className="text-c-gray-500 text-xs mb-8">
                For your security, all other active sessions have been signed
                out.
              </p>
              <Link href="/login">
                <Button className="bg-c-green-400 hover:bg-c-green-500 text-white font-semibold h-11 px-8 transition-colors">
                  Continue to Login
                </Button>
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Right Column - Light Promotional Area */}
      <section
        className="hidden w-full lg:w-[50%] xl:w-[45%] bg-white lg:flex flex-col justify-between p-6 relative bg-cover bg-center min-h-[50vh] lg:min-h-screen"
        style={{ backgroundImage: "url('/auth-bg.png')" }}
      >
        <div className="w-full max-w-3xl mx-auto z-10 pt-4 lg:pt-8 text-center lg:text-left">
          <h1 className="text-48-semibold-inter text-c-bg-750 mb-2">
            Back in control.
          </h1>
          <p className="text-24-semibold-inter text-c-bg-750">
            A fresh start — secured and ready to go
          </p>
        </div>

        <div className="flex-1 w-full flex items-center justify-center relative z-10 my-8 lg:my-12">
          <div className="relative w-full max-w-4xl aspect-[16/10]">
            <Image
              src="/auth-3.png"
              alt="RepeatSMS Dashboard Interface"
              fill
              className="object-contain"
              priority
            />
          </div>
        </div>

        <footer className="w-full z-10 text-center text-sm text-c-gray-500 pb-4">
          &copy; 2005-2025 Repeat SMS. All Rights Reserved
        </footer>
      </section>
    </main>
  );
}