"use client";

import Image from "next/image";
import Link from "next/link";
import { Home, CheckCircle2, ArrowRight, ShieldCheck, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ResetSuccessPage() {
  return (
    <main className="min-h-screen w-full flex flex-col lg:flex-row font-sans">
      {/* Left Column - Dark Auth Form */}
      <section className="w-full lg:w-[50%] xl:w-[55%] bg-c-bg-750 min-h-screen flex flex-col text-white pb-10 lg:pb-0">
        {/* Header / Nav */}
        <header className="flex justify-between items-center p-6 lg:p-8 w-full">
          <Link
            href="https://repeatsms.com"
            className="flex items-center gap-1 cursor-pointer"
          >
            <Image
              src="/rsms-logo.webp"
              alt="RepeatSMS Logo"
              width={192}
              height={67}
            />
          </Link>
          <Link
            href="https://repeatsms.com"
            className="flex flex-col items-center justify-center text-xs text-c-gray-400 hover:text-white transition-colors"
          >
            <Home className="w-5 h-5 mb-1 text-c-orange-500" />
            Home
          </Link>
        </header>

        {/* Content Container */}
        <div className="flex-1 flex flex-col justify-center items-center px-6 w-full max-w-[520px] mx-auto mt-10 lg:mt-0">
          {/* Success Icon */}
          <div className="mb-8 relative flex items-center justify-center">
            <div className="w-20 h-20 rounded-full bg-c-green-400/10 border border-c-green-400/30 flex items-center justify-center">
              <CheckCircle2 className="w-9 h-9 text-c-green-400" />
            </div>
          </div>

          {/* Main Message */}
          <div className="text-center mb-10 w-full">
            <h1 className="text-2xl lg:text-3xl font-medium mb-3">
              Password reset successful!
            </h1>
            <p className="text-c-gray-400 text-sm leading-relaxed">
              Your password has been updated and your account is secured. You
              can now sign in to RepeatSMS using your new credentials.
            </p>
          </div>

          {/* Info Cards */}
          <div className="w-full space-y-3 mb-10">
            <div className="flex items-start gap-3 bg-white/5 border border-white/10 rounded-lg px-4 py-3">
              <ShieldCheck className="w-5 h-5 text-c-green-400 mt-0.5 shrink-0" />
              <div>
                <p className="text-sm text-white font-medium">
                  All sessions signed out
                </p>
                <p className="text-xs text-c-gray-500 mt-0.5">
                  For your security, all other active sessions have been
                  terminated across your devices.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 bg-white/5 border border-white/10 rounded-lg px-4 py-3">
              <Lock className="w-5 h-5 text-c-orange-500 mt-0.5 shrink-0" />
              <div>
                <p className="text-sm text-white font-medium">
                  Keep your password safe
                </p>
                <p className="text-xs text-c-gray-500 mt-0.5">
                  Never share your password with anyone. RepeatSMS staff will
                  never ask for it.
                </p>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="w-full space-y-4">
            <Link href="/login" className="block w-full">
              <Button className="w-full bg-c-green-400 hover:bg-c-green-500 text-white font-semibold text-base h-11 transition-colors flex items-center justify-center gap-2">
                Continue to Login
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>

            <p className="text-center text-xs text-c-gray-500">
              Didn&apos;t request this change?{" "}
              <Link
                href="https://repeatsms.com/support"
                className="text-c-orange-500 hover:text-c-orange-400 transition-colors"
              >
                Contact support immediately.
              </Link>
            </p>
          </div>
        </div>
      </section>

      {/* Right Column - Light Promotional Area */}
      <section
        className="hidden w-full lg:w-[50%] xl:w-[45%] bg-white lg:flex flex-col justify-between p-6 relative bg-cover bg-center min-h-[50vh] lg:min-h-screen"
        style={{ backgroundImage: "url('/auth-bg.png')" }}
      >
        <div className="w-full max-w-3xl mx-auto z-10 pt-4 lg:pt-8 text-center lg:text-left">
          <h1 className="text-48-semibold-inter text-c-bg-750 mb-2">
            You&apos;re all set.
          </h1>
          <p className="text-24-semibold-inter text-c-bg-750">
            Your account is secure and ready to use
          </p>
        </div>

        <div className="flex-1 w-full flex items-center justify-center relative z-10 my-8 lg:my-12">
          <div className="relative w-full max-w-4xl aspect-[16/10]">
            <Image
              src="/auth-3.png"
              alt="RepeatSMS Dashboard Interface"
              fill
              className="object-contain"
              priority
            />
          </div>
        </div>

        <footer className="w-full z-10 text-center text-sm text-c-gray-500 pb-4">
          &copy; 2005-2025 Repeat SMS. All Rights Reserved
        </footer>
      </section>
    </main>
  );
}