"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Home, Mail, ArrowLeft, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function ForgotPasswordPage() {
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [email, setEmail] = useState<string>("");

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    if (email) setSubmitted(true);
  };

  return (
    <main className="min-h-screen w-full flex flex-col lg:flex-row font-sans">
      {/* Left Column - Dark Auth Form */}
      <section className="w-full lg:w-[50%] xl:w-[55%] bg-c-bg-750 min-h-screen flex flex-col text-white pb-10 lg:pb-0">
        {/* Header / Nav */}
        <header className="flex justify-between items-center p-6 lg:p-8 w-full">
          <Link
            href="https://repeatsms.com"
            className="flex items-center gap-1 cursor-pointer"
          >
            <Image
              src="/rsms-logo.webp"
              alt="RepeatSMS Logo"
              width={192}
              height={67}
            />
          </Link>
          <Link
            href="https://repeatsms.com"
            className="flex flex-col items-center justify-center text-xs text-c-gray-400 hover:text-white transition-colors"
          >
            <Home className="w-5 h-5 mb-1 text-c-orange-500" />
            Home
          </Link>
        </header>

        {/* Form Container */}
        <div className="flex-1 flex flex-col justify-center items-center px-6 w-full max-w-[520px] mx-auto mt-10 lg:mt-0">
          {!submitted ? (
            <>
              {/* Icon */}
              <div className="mb-8 flex items-center justify-center w-16 h-16 rounded-full bg-c-green-400/10 border border-c-green-400/30">
                <Mail className="w-7 h-7 text-c-green-400" />
              </div>

              <div className="text-center mb-10 w-full">
                <h1 className="text-2xl lg:text-3xl font-medium mb-3">
                  Forgot your password?
                </h1>
                <p className="text-c-gray-400 text-sm leading-relaxed">
                  No worries — it happens to the best of us. Enter the email
                  address linked to your account and we&apos;ll send you a
                  secure reset link right away.
                </p>
              </div>

              <div className="w-full mb-6">
                <h2 className="text-xl font-medium mb-1">Reset Password</h2>
                <p className="text-sm text-c-gray-400">
                  Remember your password?{" "}
                  <Link
                    href="/login"
                    className="text-c-orange-500 hover:text-c-orange-400 transition-colors"
                  >
                    Back to Login
                  </Link>
                </p>
              </div>

              <form onSubmit={handleSubmit} className="w-full space-y-5">
                {/* Email */}
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-c-gray-300 font-normal">
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your registered email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="bg-transparent border-c-gray-600 focus-visible:ring-c-green-400 text-white h-11"
                  />
                  <p className="text-xs text-c-gray-500">
                    We&apos;ll send a password reset link to this address.
                  </p>
                </div>

                {/* Submit */}
                <div className="pt-2">
                  <Button
                    type="submit"
                    className="w-full bg-c-green-400 hover:bg-c-green-500 text-white font-semibold text-base h-11 transition-colors"
                  >
                    Send Reset Link
                  </Button>
                </div>

                {/* Back link */}
                <div className="flex items-center justify-center pt-1">
                  <Link
                    href="/login"
                    className="flex items-center gap-2 text-sm text-c-gray-400 hover:text-white transition-colors"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back to Login
                  </Link>
                </div>
              </form>
            </>
          ) : (
            /* Success State */
            <div className="text-center w-full">
              <div className="mb-8 flex items-center justify-center w-16 h-16 rounded-full bg-c-green-400/10 border border-c-green-400/30 mx-auto">
                <CheckCircle2 className="w-7 h-7 text-c-green-400" />
              </div>
              <h1 className="text-2xl lg:text-3xl font-medium mb-3">
                Check your inbox
              </h1>
              <p className="text-c-gray-400 text-sm leading-relaxed mb-2">
                We&apos;ve sent a password reset link to
              </p>
              <p className="text-c-green-400 font-medium mb-6">{email}</p>
              <p className="text-c-gray-500 text-xs leading-relaxed mb-8">
                The link expires in 30 minutes. If you don&apos;t see the email,
                check your spam folder or{" "}
                <button
                  onClick={() => setSubmitted(false)}
                  className="text-c-orange-500 hover:text-c-orange-400 transition-colors underline-offset-2 underline"
                >
                  try again
                </button>
                .
              </p>
              <Link
                href="/login"
                className="flex items-center justify-center gap-2 text-sm text-c-gray-400 hover:text-white transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Login
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Right Column - Light Promotional Area */}
      <section
        className="hidden w-full lg:w-[50%] xl:w-[45%] bg-white lg:flex flex-col justify-between p-6 relative bg-cover bg-center min-h-[50vh] lg:min-h-screen"
        style={{ backgroundImage: "url('/auth-bg.png')" }}
      >
        <div className="w-full max-w-3xl mx-auto z-10 pt-4 lg:pt-8 text-center lg:text-left">
          <h1 className="text-48-semibold-inter text-c-bg-750 mb-2">
            Secure account recovery.
          </h1>
          <p className="text-24-semibold-inter text-c-bg-750">
            Your data stays safe every step of the way
          </p>
        </div>

        <div className="flex-1 w-full flex items-center justify-center relative z-10 my-8 lg:my-12">
          <div className="relative w-full max-w-4xl aspect-[16/10]">
            <Image
              src="/auth-3.png"
              alt="RepeatSMS Dashboard Interface"
              fill
              className="object-contain"
              priority
            />
          </div>
        </div>

        <footer className="w-full z-10 text-center text-sm text-c-gray-500 pb-4">
          &copy; 2005-2025 Repeat SMS. All Rights Reserved
        </footer>
      </section>
    </main>
  );
}