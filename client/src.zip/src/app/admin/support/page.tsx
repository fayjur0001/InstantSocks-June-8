"use client";

import { useState } from "react";
import { Plus, Eye, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ColumnDef } from "@tanstack/react-table";
import { ReusableTable } from "@/components/tables/ReusableTable";
import CreateTicketModal from "@/components/modals/CreateTicketModal";
import Link from "next/link";

// --- Types ---

export interface SupportTicket {
  id: string;
  ticketId: string;
  category: "Billing" | "Technical";
  subject: string;
  status: "In Progress" | "Completed" | "Open";
}

// --- Data ---

const ticketData: SupportTicket[] = [
  {
    id: "1",
    ticketId: "TCK-10001",
    category: "Billing",
    subject: "Payment processing issue",
    status: "In Progress",
  },
  {
    id: "2",
    ticketId: "TCK-10002",
    category: "Technical",
    subject: "Server connection timeout",
    status: "Completed",
  },
  {
    id: "3",
    ticketId: "TCK-10003",
    category: "Billing",
    subject: "Subscription renewal failed",
    status: "Open",
  },
];

export default function SupportPage() {
  const [page, setPage] = useState(1);
  // const [isTicketModalOpen, setIsTicketModalOpen] = useState(false);
  const [isCreateTicketOpen, setIsCreateTicketOpen] = useState(false);

  // --- Status & Category Styles (Updated for Dark Mode) ---
  const statusStyles = {
    "In Progress": "bg-c-orange-900/30 text-c-orange-400 border-c-orange-800/50",
    Completed: "bg-c-green-tw-900/30 text-c-green-tw-400 border-c-green-tw-800/50",
    Open: "bg-c-blue-900/30 text-c-blue-400 border-c-blue-800/50",
  };

  const categoryStyles = {
    Billing: "bg-c-cyan-900/30 text-c-cyan-400 border-none px-4",
    Technical: "bg-c-orange-900/30 text-c-orange-400 border-none px-4",
  };

  // --- Table Configuration ---
  const ticketColumns: ColumnDef<SupportTicket>[] = [
    {
      accessorKey: "ticketId",
      header: "Ticket ID",
      cell: ({ row }) => (
        <span className="text-c-slate-300 font-medium text-sm">
          {row.original.ticketId}
        </span>
      ),
    },
    {
      accessorKey: "category",
      header: "Category",
      cell: ({ row }) => (
        <Badge
          className={`rounded-full py-0.5 font-medium shadow-none ${
            categoryStyles[row.original.category]
          }`}
        >
          {row.original.category}
        </Badge>
      ),
    },
    {
      accessorKey: "subject",
      header: "Subject",
      cell: ({ row }) => (
        <span className="text-c-slate-300 text-sm">{row.original.subject}</span>
      ),
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => (
        <Badge
          variant="outline"
          className={`rounded-full px-4 py-0.5 border font-medium shadow-none ${
            statusStyles[row.original.status]
          }`}
        >
          {row.original.status}
        </Badge>
      ),
    },
    {
      accessorKey: "action",
      header: "Action",
      cell: ({row}) => (
        <div className="flex items-center gap-2">
          <Link href={`/admin/support/${row.original.id}`}>
            <Button
              variant="outline"
              size="sm"
              className="h-8 gap-2 border-c-slate-700 bg-transparent text-c-slate-300 hover:bg-c-slate-800 hover:text-white"
            >
              <Eye className="w-4 h-4" />
              View
            </Button>
          </Link>
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 border-c-slate-700 bg-transparent text-c-red-400 hover:bg-red-950 hover:text-c-red-300 hover:border-c-red-900"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="space-y-4 p-4 bg-black rounded-2xl">
        {/* Header inside the card */}
        <div className="flex justify-between items-start mb-6">
          <div className="space-y-1">
            <h3 className="font-bold text-white/90">Support Tickets</h3>
            <p className="text-sm text-c-slate-400">
              Manage and track your support requests
            </p>
          </div>
          <Button onClick={() => setIsCreateTicketOpen(true)}>
            <Plus className="w-4 h-4" />
            Create New Ticket
          </Button>
        </div>

        {/* Inner Table Container */}
        <div className="space-y-4">
          <h4 className="font-bold text-white/90 text-sm ml-1">All Tickets</h4>
          <div className="rounded-xl overflow-hidden border border-c-slate-800">
            <ReusableTable
              columns={ticketColumns}
              data={ticketData}
              currentPage={page}
              setCurrentPage={setPage}
              itemsPerPage={5}
              totalItems={3}
            />
          </div>
        </div>

        {/* Create Ticket Modal */}
        <CreateTicketModal
          isCreateTicketOpen={isCreateTicketOpen}
          setIsCreateTicketOpen={setIsCreateTicketOpen}
        />
      </div>
    </div>
  );
}
