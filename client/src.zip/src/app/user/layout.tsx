import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
import HeaderNav from "@/components/user/headerNav/HeaderNav";
import { AppSidebar } from "@/components/user/sidebar/app-sidebar";

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <SidebarProvider>
        <AppSidebar />
        <SidebarInset className="bg-c-white-soft">
          <HeaderNav />
          <div className="flex-1 min-w-0 px-4 pt-3 pb-3 bg-dark min-h-[calc(100dvh-68px)]">
            {children}
          </div>
        </SidebarInset>
      </SidebarProvider>
    </>
  );
}
