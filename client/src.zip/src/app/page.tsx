import { redirect } from "next/navigation";

function page() {
  const isLogedId = true;
  if (isLogedId) {
    redirect("/user");
  }
  return <div>page</div>;
}

export default page;
