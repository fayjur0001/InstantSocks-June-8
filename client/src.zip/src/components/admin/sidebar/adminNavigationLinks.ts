import {
  Clock3,
  FolderOpen,
  LayoutDashboard,
  MonitorSmartphone,
  Smartphone,
  Wallet,
  House,
  CircleDollarSign,
  Building2,
  ArrowLeftRight,
  UsersRound,
  Settings2,
  ShoppingCartIcon,
} from "lucide-react";

export const userSidebarNavigationLinkGroup = {
  navMain: [
    {
      title: "Dashboard",
      url: "/admin/dashboard",
      icon: LayoutDashboard,
    },
    {
      title: "My Rentals",
      icon: FolderOpen,
      items: [
        {
          title: "Socks5 Proxy IPs",
          url: "/admin/my-rentals/socks5-proxy",
        },
      ],
    },
    {
      title: "Deposit Balance",
      url: "/admin/deposit",
      icon: Wallet,
    },
    {
      title: "Transaction History",
      url: "/admin/transaction-history",
      icon: Clock3,
    },
  ],

  projects: [
    {
      title: "Admin Area",
      items: [
        {
          title: "Statistics",
          url: "/admin/statistics",
          icon: House,
        },
        {
          title: "Payment API",
          url: "/admin/payment-api",
          icon: CircleDollarSign,
        },
        {
          title: "Products API",
          url: "/admin/products-api",
          icon: Building2,
        },
        {
          title: "Transactions",
          url: "/admin/transactions",
          icon: ArrowLeftRight,
        },
        {
          title: "Users",
          url: "/admin/users",
          icon: UsersRound,
        },
        {
          title: "General",
          url: "/admin/settings",
          icon: Settings2,
        },
        {
          title: "Sales History",
          icon: FolderOpen,
          items: [
            {
              title: "Socks5 Proxy IPs",
              url: "/admin/sale-history/socks5-proxy",
            },
          ],
        },
      ],
    },
    {
      title: "Services",
      items: [
        {
          title: "Socks5 Proxy IPs",
          url: "/admin/socks5-proxy-ips",
          icon: Smartphone,
        },
      ],
    },
  ],
};
