"use client";

import { ChevronDown, type LucideIcon } from "lucide-react";

import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

import {
  SidebarGroup,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
} from "@/components/ui/sidebar";
import Link from "next/link";
import { usePathname } from "next/navigation";

type NavItem = {
  title: string;
  url?: string;
  icon?: LucideIcon;
  isActive?: boolean;
  items?: {
    title: string;
    url: string;
  }[];
};

export function NavMain({ items }: { items: NavItem[] }) {
  const pathname = usePathname();

  return (
    <SidebarGroup className="px-2 py-3">
      <SidebarMenu className="gap-1">
        {items.map((item) => {
          const hasSubMenu = item.items && item.items.length > 0;

          const isActive =
            pathname === item.url || pathname.startsWith(`${item.url}/`);

          // ================= SIMPLE ITEM =================
          if (!hasSubMenu) {
            return (
              <SidebarMenuItem key={item.title}>
                <SidebarMenuButton
                  asChild
                  tooltip={item.title}
                  isActive={isActive}
                  className="h-11 rounded-none border-0 bg-transparent px-3 text-[12px] font-medium text-white hover:bg-white/5 hover:text-white data-[active=true]:border-l-2 data-[active=true]:border-c-green-500 data-[active=true]:bg-transparent data-[active=true]:pl-[10px] data-[active=true]:text-c-green-500"
                >
                  <Link href={`${item.url}`}>
                    {item.icon && <item.icon />}
                    <span>{item.title}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            );
          }

          // ================= ITEM WITH SUB MENU =================
          return (
            <Collapsible
              key={item.title}
              asChild
              defaultOpen={item.isActive}
              className="group/collapsible"
            >
              <SidebarMenuItem>
                <CollapsibleTrigger asChild>
                  <SidebarMenuButton
                    tooltip={item.title}
                    className="h-11 rounded-none border-0 bg-transparent px-3 text-[12px] font-medium text-white hover:bg-white/5 hover:text-white data-[state=open]:bg-transparent data-[state=open]:text-white"
                  >
                    {item.icon && <item.icon />}
                    <span>{item.title}</span>
                    <ChevronDown className="ml-auto size-4 text-c-slate-400 transition-transform duration-200 group-data-[state=open]/collapsible:rotate-180" />
                  </SidebarMenuButton>
                </CollapsibleTrigger>

                <CollapsibleContent>
                  <SidebarMenuSub className="mt-1 gap-1 pl-5">
                    {item.items!.map((subItem) => {
                      const isSubActive =
                        pathname === subItem.url ||
                        pathname.startsWith(`${subItem.url}/`);

                      return (
                        <SidebarMenuSubItem key={subItem.title}>
                          <SidebarMenuSubButton
                            asChild
                            isActive={isSubActive}
                            className="relative h-9 rounded-none bg-transparent py-1.5 ps-5 pe-3 text-[12px] text-white/90 hover:bg-transparent hover:text-white data-[active=true]:bg-transparent data-[active=true]:text-green before:absolute before:left-0 before:top-1/2 before:h-px before:w-2 before:-translate-y-1/2 before:bg-white/50 data-[active=true]:before:bg-green"
                          >
                            <Link href={subItem.url}>
                              <span>{subItem.title}</span>
                            </Link>
                          </SidebarMenuSubButton>
                        </SidebarMenuSubItem>
                      );
                    })}
                  </SidebarMenuSub>
                </CollapsibleContent>
              </SidebarMenuItem>
            </Collapsible>
          );
        })}
      </SidebarMenu>
    </SidebarGroup>
  );
}
