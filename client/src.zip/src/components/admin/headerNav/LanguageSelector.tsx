"use client";

import { useState } from "react";
import useDropdown from "@/hooks/useDropdown";
import { ChevronUp } from "lucide-react";
import Image from "next/image";

interface Language {
  name: string;
  flag: string;
}

const LanguageSelector = () => {
  const { dropdownOpen, setDropdownOpen, dropdownRef } = useDropdown();
  const [selectedLanguage, setSelectedLanguage] = useState<Language>({
    name: "English",
    flag: "/flag1.png",
  });

  const languages = [
    { name: "English", flag: "/flag1.png" },
    { name: "Spanish", flag: "/flag2.png" },
    { name: "French", flag: "/flag3.png" },
  ];

  const handleLanguageChange = (lang: Language) => {
    setSelectedLanguage(lang);
    setDropdownOpen(false);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Trigger Button */}
      <button
        onClick={() => setDropdownOpen((prev) => !prev)}
        className="flex items-center gap-2 px-3 py-2 border rounded-[8px] border-c-gray-200  transition duration-200 cursor-pointer"
      >
        <Image src={selectedLanguage?.flag} width={26} height={18} alt={""} className="w-[22px] h-[14px]" />
        <span className="text-[16px] font-medium">
          {selectedLanguage?.name}
        </span>
        <ChevronUp
          className={`w-5 transition-transform ${
            dropdownOpen ? "rotate-0" : "rotate-180"
          }`}
        />
      </button>

      {/* Dropdown Menu */}
      {dropdownOpen && (
        <div className="absolute border border-brand-300 p-3 space-y-3 left-0 mt-2 w-34 bg-white text-c-gray-800 shadow-xl rounded-lg z-10 overflow-hidden">
          {languages?.map((lang: Language) => (
            <button
              key={lang?.name}
              onClick={() => handleLanguageChange(lang as Language)}
              className={`flex items-center gap-2 w-full text-left text-[16px] text-gray-950 font-semibold cursor-pointer`}
            >
              <Image src={lang.flag} width={30} height={22} alt={""} className="w-[22px] h-[14px]" />
              {lang.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default LanguageSelector;
