"use client";

import { useState } from "react";
import { ReusableTable } from "@/components/tables/ReusableTable";
import { ColumnDef } from "@tanstack/react-table";

export interface ProxyData {
  id: string;
  username: string;
  port: string;
  portType: "Shared" | "Exclusive";
  location: string;
  serviceName: string;
  duration: string;
  amount: string;
  price: string;
}

const dummyData: ProxyData[] = [
  { id: "01", username: "Recorn", port: "50033", portType: "Shared", location: "NJ", serviceName: "101Plus", duration: "Day", amount: "2 units", price: "$ 2.48" },
  { id: "02", username: "Recorn", port: "50039", portType: "Exclusive", location: "NJ", serviceName: "Telgram", duration: "Month", amount: "1 unit", price: "$ 1.24" },
];

export default function ProxyTable() {
  const [page, setPage] = useState(1);

  const columns: ColumnDef<ProxyData>[] = [
    { accessorKey: "id", header: "#", cell: ({ row }) => <span className="text-c-slate-400">{row.original.id}</span> },
    { accessorKey: "username", header: "Username", cell: ({ row }) => <span className="text-c-slate-200">{row.original.username}</span> },
    { 
      accessorKey: "port", 
      header: "Port", 
      cell: ({ row }) => (
        <span className="text-c-slate-200">
          {row.original.port} <span className="text-c-slate-500">( {row.original.portType} )</span>
        </span>
      ) 
    },
    { accessorKey: "location", header: "Location", cell: ({ row }) => <span className="text-c-slate-200">{row.original.location}</span> },
    { accessorKey: "serviceName", header: "Service Name", cell: ({ row }) => <span className="text-c-slate-200">{row.original.serviceName}</span> },
    { accessorKey: "duration", header: "Duration", cell: ({ row }) => <span className="text-c-slate-200">{row.original.duration}</span> },
    { accessorKey: "amount", header: "Amount", cell: ({ row }) => <span className="text-c-slate-200">{row.original.amount}</span> },
    { accessorKey: "price", header: "Price", cell: ({ row }) => <span className="text-c-slate-200">{row.original.price}</span> },
  ];

  return (
    <ReusableTable
      columns={columns}
      data={dummyData}
      currentPage={page}
      setCurrentPage={setPage}
      itemsPerPage={10}
      totalItems={dummyData.length}
    />
  );
}