"use client";

import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const CreateTicketModal = ({
  isCreateTicketOpen,
  setIsCreateTicketOpen,
}: {
  isCreateTicketOpen: boolean;
  setIsCreateTicketOpen: (open: boolean) => void;
}) => {
  return (
    <Dialog open={isCreateTicketOpen} onOpenChange={setIsCreateTicketOpen}>
      <DialogContent className="sm:max-w-[650px] p-0 overflow-hidden gap-0 bg-black border border-white/20 shadow-xl shadow-white/10">
        
        {/* Header Section */}
        <div className="p-8 pb-4">
          <h3 className="text-xl font-bold text-white/70 mb-1">Create Support Ticket</h3>
          <p className="text-sm text-c-slate-400">
            Tell us how we can help you. Fill in the details below.
          </p>
        </div>

        {/* Body Section (Form) */}
        <div className="px-8 pb-8 space-y-6">
          
          {/* Category Selection */}
          <div className="space-y-2">
            <Label className="font-semibold text-white/70 text-sm">
              Select Category
            </Label>
            <Select>
              <SelectTrigger className="w-full h-11 border-white/10 bg-transparent text-c-slate-300 focus:ring-c-purple-500">
                <SelectValue placeholder="Support Category" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-950 border-c-slate-800 text-c-slate-300">
                <SelectItem value="general" className="focus:bg-c-slate-800 focus:text-white">General</SelectItem>
                <SelectItem value="proxies-issues" className="focus:bg-c-slate-800 focus:text-white">Proxies Issues</SelectItem>
                <SelectItem value="number-sms-issues" className="focus:bg-c-slate-800 focus:text-white">Number/SMS Issues</SelectItem>
                <SelectItem value="devices-issues" className="focus:bg-c-slate-800 focus:text-white">Devices Issues</SelectItem>
                <SelectItem value="payment-billing" className="focus:bg-c-slate-800 focus:text-white">Payment/Billing</SelectItem>
                <SelectItem value="technical" className="focus:bg-c-slate-800 focus:text-white">Technical</SelectItem>
                <SelectItem value="feedback" className="focus:bg-c-slate-800 focus:text-white">Feedback</SelectItem>
                <SelectItem value="others" className="focus:bg-c-slate-800 focus:text-white">Others</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Subject Field */}
          <div className="space-y-2">
            <Label className="font-semibold text-white/70 text-sm">
              Subject
            </Label>
            <Input 
              placeholder="Write here the subject" 
              className="h-11 border-white/10 bg-transparent text-c-slate-200 placeholder:text-c-slate-500 focus-visible:ring-c-purple-500" 
            />
          </div>

          {/* Message Field */}
          <div className="space-y-2">
            <Label className="font-semibold text-white/70 text-sm">
              Message
            </Label>
            <Textarea 
              placeholder="explain your problem in details..." 
              className="min-h-[120px] border-white/10 bg-transparent text-c-slate-200 placeholder:text-c-slate-500 focus-visible:ring-c-purple-500 resize-none" 
            />
          </div>

        </div>

        {/* Footer Section (Buttons) */}
        <div className="p-8 pt-0 flex gap-4">
          <Button 
            variant="outline" 
            className="flex-1 h-11 border-c-slate-700 bg-transparent text-c-slate-300 hover:bg-c-slate-800 hover:text-white font-semibold"
            onClick={() => setIsCreateTicketOpen(false)}
          >
            Cancel
          </Button>
          <Button 
            className="flex-1 h-11 "
          >
            Open Ticket
          </Button>
        </div>

      </DialogContent>
    </Dialog>
  );
};

export default CreateTicketModal;