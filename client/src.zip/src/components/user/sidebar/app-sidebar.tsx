"use client";

import * as React from "react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  useSidebar,
} from "@/components/ui/sidebar";
import { NavMain } from "./nav-main";
import { NavProjects } from "./nav-projects";
import Image from "next/image";
import { userSidebarNavigationLinkGroup } from "./userNavigationLinks";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const { state, toggleSidebar } = useSidebar();
  return (
    <Sidebar
      collapsible="icon"
      {...props}
      className="border-r-0 bg-black text-white"
    >
      <SidebarHeader className="bg-transparent px-4 py-3">
        <div className="flex items-center gap-4 justify-between">
          {state === "collapsed" ? (
            <Image src="/sm-logo-2.png" width={36} height={36} alt="Logo small" />
          ) : (
            <Image
              src="/logo.webp"
              width={220}
              height={47}
              className="h-full object-contain max-w-[calc(100%-66px)] lg:max-w-full"
              alt="Logo"
            />
          )}

          {/* Close button — only visible on mobile (below lg) */}
          <Button
            size="icon"
            onClick={toggleSidebar}
            className="lg:hidden ml-auto text-white hover:bg-white/10 hover:text-white shrink-0"
            aria-label="Close sidebar"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
      </SidebarHeader>
      <SidebarContent className="bg-transparent">
        <NavMain items={userSidebarNavigationLinkGroup.navMain} />
        <NavProjects projects={userSidebarNavigationLinkGroup.projects} />
      </SidebarContent>
      <SidebarFooter className="bg-transparent p-0">
        <div className="pb-2">
          <p className="text-[10px] text-center wrap-break-word">
            <a
              href="https://repeatsms.com/terms-conditions/"
              className="text-green hover:underline"
            >
              TOS
            </a>
            <span className="text-white/50 mx-1 text-[8px]">|</span>
            <a href="#" className="text-green hover:underline">
              {state === "collapsed" ? "PP" : "Privacy Policy"}
            </a>
          </p>
          <p className="text-[8px] text-center text-white/30">
            © Present, RepeatSMS.
          </p>
        </div>
      </SidebarFooter>
      {/* <SidebarRail /> */}
    </Sidebar>
  );
}
