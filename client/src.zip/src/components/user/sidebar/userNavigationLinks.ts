import {
  Clock3,
  FolderOpen,
  LayoutDashboard,
  MonitorSmartphone,
  Smartphone,
  Wallet,
} from "lucide-react";

export const userSidebarNavigationLinkGroup = {
  navMain: [
    {
      title: "Dashboard",
      url: "/user/dashboard",
      icon: LayoutDashboard,
    },
    {
      title: "My Rentals",
      icon: FolderOpen,
      items: [
        {
          title: "Socks5 Proxy IPs",
          url: "/user/my-rentals/socks5-proxy",
        },
      ],
    },
    {
      title: "Deposit Balance",
      url: "/user/deposit",
      icon: Wallet,
    },
    {
      title: "Transaction History",
      url: "/user/transaction-history",
      icon: Clock3,
    },
  ],

  projects: [
    {
      title: "Services",
      items: [
        {
          title: "Socks5 Proxy IPs",
          url: "/user/socks5-proxy-ips",
          icon: Smartphone,
        },
      ],
    },
  ],
};
