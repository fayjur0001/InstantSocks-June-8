"use client";

import { SidebarTrigger } from "@/components/ui/sidebar";
// import LanguageSelector from "./LanguageSelector";
import AdminUserDropdown from "./AdminUserDropdown";
import NotificationDropdown from "./NotificationDropdown";
import { Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

const user = {
  name: "John Doe",
  email: "johndoe@gmail.com",
  image: "/user.jpeg",
};

const HeaderNav = () => {
  const handleLogout = () => {
    console.log("logout");
  };

  return (
    <header className="sticky top-0 z-50 flex h-17 shrink-0 items-center gap-2 border-b border-white/10 bg-black px-4">
      <div className="flex items-center gap-2">
        <SidebarTrigger className="" />
      </div>
      {/* Right Section: User Dropdown */}
      <div
        className="flex items-center gap-4 ml-auto
      "
      >
        <div className="flex items-center gap-4">
          <NotificationDropdown />
          {/* <LanguageSelector /> */}
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden h-11 w-fit items-center gap-3 rounded-[8px] border border-white/10 bg-white/5 px-2.5 py-1 lg:flex">
            {/* Wallet Icon and Balance */}
            <div className="flex items-center gap-1.5">
              <Wallet className="h-3.75 w-3.75 text-white/80" strokeWidth={2.5} />
              <span className="text-[14px] leading-none font-medium text-white">
                $105
              </span>
            </div>

            {/* Deposit Action */}
            <Link href={"/user/deposit"}>
              <Button
                variant="ghost"
                className="h-6.5 border border-white/10 px-2 text-[12px]! text-c-green-500 font-semibold text-lg hover:bg-white/10 hover:text-c-green-300"
              >
                Deposit
              </Button>
            </Link>
          </div>
          <AdminUserDropdown user={user} handleLogout={handleLogout} />
        </div>
      </div>
    </header>
  );
};

export default HeaderNav;
